UMWPluginInstaller
==================
A project for Martha Burtis to create a Plugin-installing Plugin on WordPress.
