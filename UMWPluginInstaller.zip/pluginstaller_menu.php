<div class="wrap">
<h2>PlugInstaller</h2>
<h3>PlugInstaller Menu</h3>

<table cellpadding="0" cellspacing="0"><tr>
<form action="pluginstaller_search.php" method="post">
<td>
<input type="text" name="search_term" placeholder="Search by course or professor" size="30" /></td>
<td><?php submit_button('Search') ?></td>
</form></tr>
<tr><td>-or-</td></tr>
<tr>
<form action="pluginstaller_download.php" method="post">
<td>
	<select name="package">
		<option selected disabled>Choose a package</option>
		<?php
		// Programmatically fill in option tags here.
		?>
	</select></td>

	<td><?php submit_button('Install') ?></td>
</form></tr></table>

</div>
