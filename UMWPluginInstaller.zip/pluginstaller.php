<?php
/**
 * Plugin Name: UMW PlugInstaller
 * Description: Allows fast and easy installation of predetermined packages of plugins/themes/etc. for Wordpress
 * Version: 0.1
 * Author: Morgan Brown, Frankie DePaola, Logan Wholey
 * License: GPL2
 */
 
 /*  Copyright 2014  Morgan Brown, Frank DePaola, Logan Wholey  (email : mbrown7@mail.umw.edu, depaolafv@gmail.com, lwholeyumw@gmail.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

//hook for the menu page
add_action('admin_menu','add_pluginstaller_menu');

//menu page function
function add_pluginstaller_menu(){
	add_menu_page('PlugInstaller','PlugInstaller Menu','administrator','pluginstaller','pluginstaller_display_menu');
}

function pluginstaller_display_menu(){
	require_once('pluginstaller_menu.php');
}

//this reads the file into a string
//read in the file that contains package information for all packages
//$package = file_get_contents('http://www.placeourfileishosted.com/');
$package = file_get_contents('./testfile.csv');
//alternative we can say ('./file.txt', true); to get the file from our directory if needed
?>
